1. Delete all backend/.db files
2. pip install -r requirements.txt & run the same command in the backend folder, again
3. Run init_db.py
4. Run main.py
5. Run " npm run dev" in planner-ai-frontend
6. Create user and you should be able to perform all operations from the user diagram documentation file